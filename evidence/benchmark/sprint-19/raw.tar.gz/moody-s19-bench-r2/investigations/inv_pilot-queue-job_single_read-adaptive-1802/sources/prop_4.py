PLAN = {'scenario_id': 'jq-stale-read', 'config': 'baseline', 'faults': [], 'looking_for': 'any_violation'}
PROTOCOL = "mb-exp/1"
observations = EXPERIMENT_INPUT["observations"]

if not observations:
    action = {"protocol": PROTOCOL, "action": "run_target_agent",
              "scenario_id": PLAN["scenario_id"], "config": PLAN["config"]}
    if PLAN["faults"] is not None:
        action["faults"] = PLAN["faults"]
    emit(action)
elif len(observations) == 1:
    emit({"protocol": PROTOCOL, "action": "inspect_observation",
          "run_ref": observations[0]["run_ref"], "section": "tool_trace"})
elif len(observations) == 2:
    emit({"protocol": PROTOCOL, "action": "inspect_observation",
          "run_ref": observations[0]["run_ref"], "section": "state_summary"})
else:
    run = observations[0]
    trace = observations[1]["tool_calls"]
    errors = sum(1 for call in trace if not call["ok"])
    seen = PLAN["looking_for"] in run["finding_codes"]
    emit({"protocol": PROTOCOL, "action": "finish_experiment",
          "conclusion": "behavior_observed" if seen else "behavior_not_observed",
          "summary": f"looked for {PLAN['looking_for']}; saw {len(trace)} calls, {errors} errors, "
                     f"{observations[2]['objective_matching_records']} matching records"})
