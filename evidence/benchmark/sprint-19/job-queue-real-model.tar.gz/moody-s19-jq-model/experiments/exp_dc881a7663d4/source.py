seen = EXPERIMENT_INPUT["observations"]
runs = [o for o in seen if o["kind"] == "target_run"]
done = [o["section"] for o in seen if o["kind"] == "inspection"]

# Check if any prior run has already been inspected for tool_trace
if not runs:
    # Run target agent with a stale_read fault on list_jobs
    emit({"protocol": "mb-exp/1", "action": "run_target_agent", "scenario_id": "jq-normal", "config": "baseline", "faults": [{"kind": "stale_read", "occurrence": 1, "span": 3, "error_code": "timeout"}]})
elif "tool_trace" not in done:
    # Inspect tool trace to see if the agent failed to detect job existence
    emit({"protocol": "mb-exp/1", "action": "inspect_observation", "run_ref": runs[0]["run_ref"], "section": "tool_trace"})
else:
    # Finish experiment if no further inspection is needed
    emit({"protocol": "mb-exp/1", "action": "finish_experiment", "conclusion": "inconclusive", "summary": "No evidence of failure in job existence verification under stale_read fault."})