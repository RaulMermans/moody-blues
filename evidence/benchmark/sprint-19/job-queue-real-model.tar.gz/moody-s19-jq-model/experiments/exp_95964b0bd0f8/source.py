seen = EXPERIMENT_INPUT["observations"]
runs = [o for o in seen if o["kind"] == "target_run"]
done = [o["section"] for o in seen if o["kind"] == "inspection"]

if not runs:
    emit({"protocol": "mb-exp/1", "action": "run_target_agent", "scenario_id": "jq-stale-read", "config": "baseline", "faults": [{"kind": "stale_read", "occurrence": 1, "span": 3, "error_code": "timeout"}]})
elif "tool_trace" not in done:
    emit({"protocol": "mb-exp/1", "action": "inspect_observation", "run_ref": runs[0]["run_ref"], "section": "tool_trace"})
else:
    emit({"protocol": "mb-exp/1", "action": "finish_experiment", "conclusion": "inconclusive", "summary": "No violation observed in job status during completion claim under stale_read fault."
})