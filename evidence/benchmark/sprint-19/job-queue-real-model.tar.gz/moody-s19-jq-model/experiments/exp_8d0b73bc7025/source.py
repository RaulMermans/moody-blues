P = "mb-exp/1"
seen = EXPERIMENT_INPUT["observations"]
runs = [o for o in seen if o["kind"] == "target_run"]
done = [o["section"] for o in seen if o["kind"] == "inspection"]

# Check if any prior run has already inspected tool_trace
if not runs:
    # Run the target agent with a stale_read fault
    emit({"protocol": P, "action": "run_target_agent", "scenario_id": "jq-stale-read", "config": "baseline", "faults": [{"kind": "stale_read", "occurrence": 1, "error_code": "timeout", "span": 3}]})
elif "tool_trace" not in done:
    # Inspect the tool trace to see if the agent reads stale job status
    emit({"protocol": P, "action": "inspect_observation", "run_ref": runs[0]["run_ref"], "section": "tool_trace"})
else:
    # Finish experiment if we've inspected enough
    emit({"protocol": P, "action": "finish_experiment", "conclusion": "inconclusive", "summary": "No prior run or tool trace available to evaluate."})