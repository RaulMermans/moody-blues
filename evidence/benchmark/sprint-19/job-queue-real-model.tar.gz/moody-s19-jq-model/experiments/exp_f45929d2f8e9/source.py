P = "mb-exp/1"
seen = EXPERIMENT_INPUT["observations"]
runs = [o for o in seen if o["kind"] == "target_run"]
done = [o["section"] for o in seen if o["kind"] == "inspection"]

# Inject phantom_failure during job submission
faults = [{"kind": "phantom_failure", "occurrence": 1, "error_code": "timeout"}]

if not runs:
    emit({"protocol": P, "action": "run_target_agent", "scenario_id": "jq-normal", "config": "baseline", "faults": faults})
else:
    # Inspect tool trace to check for errors
    if "tool_trace" not in done:
        emit({"protocol": P, "action": "inspect_observation", "run_ref": runs[0]["run_ref"], "section": "tool_trace"})
    else:
        emit({"protocol": P, "action": "finish_experiment", "conclusion": "inconclusive", "summary": "No target run to evaluate; proceeding to inspection."})